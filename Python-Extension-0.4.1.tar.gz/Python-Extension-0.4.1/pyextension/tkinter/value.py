class AV:
    finish = ''
def s1(event):
    AV.finish = None
def s2(event):
    AV.finish = False
def s3(event):
    AV.finish = True
# Askyesnocancel Value
